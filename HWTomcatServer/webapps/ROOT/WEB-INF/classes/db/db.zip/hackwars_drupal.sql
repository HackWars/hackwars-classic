-- MySQL dump 10.13  Distrib 5.1.36, for Win32 (ia32)
--
-- Host: localhost    Database: hackwars_drupal
-- ------------------------------------------------------
-- Server version	5.1.36-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 DROP DATABASE IF EXISTS `hackwars_drupal`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hackwars_drupal` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hackwars_drupal`;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL,
  `mail` varchar(64) DEFAULT '',
  `mode` tinyint(4) NOT NULL DEFAULT '0',
  `sort` tinyint(4) DEFAULT '0',
  `threshold` tinyint(4) DEFAULT '0',
  `theme` varchar(255) NOT NULL DEFAULT '',
  `signature` varchar(255) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `login` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `timezone` varchar(8) DEFAULT NULL,
  `language` varchar(12) NOT NULL DEFAULT '',
  `picture` varchar(255) NOT NULL DEFAULT '',
  `init` varchar(64) DEFAULT '',
  `data` longtext,
  `ip` varchar(20) NOT NULL,
  `news` enum('0','1') NOT NULL,
  `fileio` tinyint(4) NOT NULL DEFAULT '0',
  `hacktendo` tinyint(4) NOT NULL DEFAULT '0',
  `propack` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT '$5 email/domain/website pack',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`name`),
  KEY `access` (`access`),
  KEY `created` (`created`),
  KEY `mail` (`mail`)
) ENGINE=MyISAM AUTO_INCREMENT=18403 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (0,'','*4809D2B4F078FA10D7D1B151A3706AF61E72954E','no@mail.com',0,0,0,'','',1204747233,0,0,0,'sites/de','','a:8:{s:3:\"ip1\";s:3:\"155\";s:3:\"ip2\";s:3:\"209\";s:3:\"ip3\";s:1:\"7\";s:3:\"ip4\";s:3:\"013\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-2723b7f5c3bba21ddd1a2762f9c678d0\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','','17194','','',0,0,'Y'),(11770,'jamjardavies','*945BDA8CA9627648282BB198C31ED6336496237D','no@mail.com',0,0,0,'','Jamjar\r\nCo-Leader of EliteNet',1205427107,1247198825,1246830094,1,'-18000','','sites/default/files/pictures/picture-11770.jpg','','a:3:{s:13:\"form_build_id\";s:37:\"form-2115ad95b7a2fd5cd095469d0fcd9808\";s:14:\"picture_delete\";i:0;s:14:\"picture_upload\";s:0:\"\";}','152.009.3.113','1',1,1,'Y'),(9883,'geckotoss','*6F63F0AA86EAF509F096D75F2F1E358CC2185F1C','no@mail.com',0,0,0,'garland','<img src=\"http://www.hackwars.net/sig.php?name=geckotoss\">',1205427105,1247235695,1247147491,1,'-18000','','','','a:3:{s:13:\"form_build_id\";s:37:\"form-b71fffbfbee04e3208de6c6c01e096da\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','238.099.4.179','1',1,1,'Y'),(9881,'Johnny_Heart','*6A4EE03BB584BA882F281D0E6CA300DE6A6F3CC6','no@mail.com',0,0,0,'garland','<img src=\"http://www.hackwars.net/sig.php?name=johnny_heart\" />',1205427105,1246989772,1246989772,1,'-18000','','','','a:3:{s:13:\"form_build_id\";s:37:\"form-7ecec5846cd439d721a04d1f4d73c27e\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','192.168.2.002','1',1,1,'N'),(12534,'Surfpup','*25E7EADDC2354F49F001AE2478D54F9B773300DD','no@mail.com',0,0,0,'','',2008,1247092369,1246238171,1,NULL,'','','','a:6:{s:3:\"ip1\";s:3:\"035\";s:3:\"ip2\";s:3:\"156\";s:3:\"ip3\";s:1:\"4\";s:3:\"ip4\";s:3:\"054\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-ee6bd02b6120eaa70c2f1cc67b8f1d70\";}','035.156.4.054','1',1,1,'Y'),(13285,'TerribleTrioJoe','*E6FBE00E541F0085B7157DB5C166833496A2C6AD','no@mail.com',0,0,0,'','-TTJ\r\n\r\n(Im in ur compilerz lolin\' ur codez !)',1208978088,1247237618,1246422083,1,'-18000','','sites/default/files/pictures/picture-13285.jpg','','a:8:{s:3:\"ip1\";s:3:\"011\";s:3:\"ip2\";s:3:\"028\";s:3:\"ip3\";s:1:\"1\";s:3:\"ip4\";s:3:\"990\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-3a7de683d03053a8020f6f40e996e065\";s:14:\"picture_delete\";i:0;s:14:\"picture_upload\";s:0:\"\";}','011.028.1.990','1',1,1,'N'),(15291,'mecha_cephalon','*2A995803DF9B8F20F398FE95820AB565C268FB98','no@mail.com',0,0,0,'garland','',1224804766,1247020676,1247017653,1,'-18000','','','','a:8:{s:3:\"ip1\";s:3:\"800\";s:3:\"ip2\";s:3:\"813\";s:3:\"ip3\";s:1:\"5\";s:3:\"ip4\";s:3:\"691\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-42d844844d0aecb3bb9f286f44028a10\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','800.813.5.691','1',0,0,'Y'),(15300,'sixteen_faces','*1F88B2470162888680D30A2B4794D84F8A2EA174','no@mail.com',0,0,0,'garland','',1224894106,1241105576,1239554930,1,'-18000','','','','a:8:{s:3:\"ip1\";s:3:\"112\";s:3:\"ip2\";s:3:\"163\";s:3:\"ip3\";s:1:\"2\";s:3:\"ip4\";s:3:\"183\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-07fe51bb03783098cc0e895f1bfc2fac\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','112.163.2.183','1',0,0,'N'),(17048,'Bastard','*7F1BEA48CD5208DA61CE25E81DD38716985970FF','no@mail.com',0,0,0,'','',1235112737,1246878830,1246878830,1,'-18000','','','','a:8:{s:3:\"ip1\";s:2:\"69\";s:3:\"ip2\";s:3:\"139\";s:3:\"ip3\";s:1:\"6\";s:3:\"ip4\";s:2:\"48\";s:3:\"ToS\";s:1:\"1\";s:13:\"form_build_id\";s:37:\"form-5fbf3e9097dbc55c99fac1b0c329841d\";s:14:\"picture_delete\";s:0:\"\";s:14:\"picture_upload\";s:0:\"\";}','69.139.6.48','0',0,0,'Y');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-07-13 14:10:09
