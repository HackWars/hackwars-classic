-- 
--  db-truncatedata.sql
--  HackWars
--  
--  Created by Dana Rea on 2009-01-17.
--  Copyright 2009 Dana Rea. All rights reserved.
-- 

TRUNCATE network;
TRUNCATE apis;
TRUNCATE attached_networks;
TRUNCATE bookmarks;
TRUNCATE challenges;
TRUNCATE client;
TRUNCATE domains;
TRUNCATE domainsearch;
TRUNCATE drop_table;
TRUNCATE facebook;
TRUNCATE facebook_bank;
TRUNCATE items;
TRUNCATE network_npc;
TRUNCATE newtutorials;
TRUNCATE sounds;
TRUNCATE stats;
TRUNCATE tutorials;
TRUNCATE user;
